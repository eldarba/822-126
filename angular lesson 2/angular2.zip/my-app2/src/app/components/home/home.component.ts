import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  public x: string = 'hello';
  public date: Date = new Date();
  public b: boolean = true;
  constructor() {}

  ngOnInit(): void {
    setTimeout(() => {
      this.b = false;
    }, 3000);
  }

  public f(): any {
    alert('HI');
  }
}
