import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  public x: string = 'hello';
  public date: Date = new Date();
  public b: boolean = true;
  public arr = ['aaa', 'bbb', 'ccc', 'ddd'];
  public color = 'pink';

  constructor() {}

  ngOnInit(): void {
    setTimeout(() => {
      this.b = false;
      this.color = 'green';
    }, 3000);
  }

  public f(): any {
    alert('HI');
  }

  public getColor(): string {
    if (this.b) {
      return 'red';
    } else {
      return 'blue';
    }
  }
}
