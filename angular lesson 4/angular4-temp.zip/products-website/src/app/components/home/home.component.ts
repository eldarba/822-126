import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  public discount = Math.floor(Math.random() * 26);
  public currDate = new Date();
  public imageWidth: number = 300;
  public applyColors = true;
  public isWinter: boolean;
  public fruites = ['Bannanas', 'Oranges', 'Peatches', 'Watermelons'];

  // define an ngStyle object
  public headerStyle = {
    fontStyle: this.discount > 5 ? 'italic' : 'normal',
    color: this.discount > 10 ? 'red' : 'black',
  };

  constructor() {
    let month = this.currDate.getMonth() + 1;
    this.isWinter = month >= 11 || month <= 3;

    for (let e of this.fruites) {
      console.log(e);
    }
  }

  ngOnInit(): void {}

  // methods to controll the image width
  public increaseWidth(): void {
    this.imageWidth += 10;
  }
  public decreaseWidth(): void {
    this.imageWidth -= 10;
  }
  public reset(): void {
    this.imageWidth = 300;
  }
}
