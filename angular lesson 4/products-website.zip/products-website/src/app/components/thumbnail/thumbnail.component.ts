import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css'],
})
export class ThumbnailComponent implements OnInit {
  @Input() // exposed throw selector
  public imageSource!: string;

  @Output()
  public onImageClick: EventEmitter<{
    eventName: string;
    eventValue: any;
  }> = new EventEmitter();

  constructor() {}

  ngOnInit(): void {}

  public imageClicked(): void {
    // raising an event
    this.onImageClick.emit({
      eventName: 'onImageClick',
      eventValue: this.imageSource,
    });
  }
}
