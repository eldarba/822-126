import { Injectable } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';
import { Product } from '../models/product.model';

@Injectable({
  providedIn: 'root',
})
export class ProductsService {
  constructor() {}

  // synchrounous
  public getAllProducts(): Product[] {
    let arr: Product[] = [];
    arr.push(new Product(1, 'Apple', 7, 320));
    arr.push(new Product(2, 'Bannana', 4.3, 700));
    arr.push(new Product(3, 'Peach', 12.7, 250));
    arr.push(new Product(4, 'Avocado', 25, 70));
    return arr;
  }

  // asynchrounous
  public getAllProductsAsynch(): Observable<Product[]> {
    return new Observable((subscriber: Subscriber<Product[]>) => {
      setTimeout(() => {
        try {
          if (Math.random() < 0.5) {
            let arr: Product[] = [];
            arr.push(new Product(1, 'Apple', 7, 320));
            arr.push(new Product(2, 'Bannana', 4.3, 700));
            arr.push(new Product(3, 'Peach', 12.7, 250));
            arr.push(new Product(4, 'Avocado', 25, 70));
            subscriber.next(arr); // success
          } else {
            throw new Error('get all products failed');
          }
        } catch (error) {
          subscriber.error(error); // failure
        }
      }, 3000);
    });
  }
}
