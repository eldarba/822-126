import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  public discount = Math.floor(Math.random() * 26);
  public currDate = new Date();
  public imageWidth: number = 300;
  public applyColors = true;
  public isWinter: boolean;
  public fruites = ['Bannanas', 'Oranges', 'Peatches', 'Watermelons'];

  // the router object
  private router: Router;

  // define an ngStyle object
  public headerStyle = {
    fontStyle: this.discount > 5 ? 'italic' : 'normal',
    color: this.discount > 10 ? 'red' : 'black',
  };

  constructor(router: Router, private title: Title) {
    this.router = router;
    let month = this.currDate.getMonth() + 1;
    this.isWinter = month >= 11 || month <= 3;
  }

  ngOnInit(): void {
    this.title.setTitle('Home');
  }

  // methods to controll the image width
  public increaseWidth(): void {
    this.imageWidth += 10;
  }
  public decreaseWidth(): void {
    this.imageWidth -= 10;
  }
  public reset(): void {
    this.imageWidth = 300;
  }

  public nav() {
    this.router.navigate(['about']);
    let x = Math.random();
    if (x < 0.5) {
      console.log('small');
    } else {
      console.log('big');
    }
    console.log(x);
    console.log(3);
  }
}
