import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { Product } from 'src/app/models/product.model';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css'],
})
export class AddProductComponent implements OnInit {
  public product = new Product();

  constructor(private productService: ProductsService) {}

  ngOnInit(): void {}

  public addProduct() {
    console.log(`
    product name: ${this.product.name}
    product price: ${this.product.price}
    product stock: ${this.product.stock}
    `);

    this.productService.addProductHttp(this.product).subscribe(
      (p) => {
        alert('product added. id is ' + p.id);
      },
      (e) => {
        console.dir(e);
      }
    );
  }

  public showControl(x: NgModel) {
    console.dir(x);
    console.log(x.valid);
  }
}
