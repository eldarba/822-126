import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from 'src/app/models/product.model';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css'],
})
export class ProductDetailsComponent implements OnInit {
  public product!: Product;

  // inject ActivatedRoute
  constructor(
    private activatedRoute: ActivatedRoute,
    private productService: ProductsService
  ) {}

  ngOnInit(): void {
    console.dir(this.activatedRoute);
    // use the ActivatedRoute to find parameter values
    let id = this.activatedRoute.snapshot.params.id;
    this.productService.getProductHttp(id).subscribe(
      (p) => {
        this.product = p;
      },
      (e) => {
        console.dir(e);
        alert(e.error.message);
      }
    );
  }
}
