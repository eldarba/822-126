import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';
import { Product } from '../models/product.model';

@Injectable({
  providedIn: 'root',
})
export class ProductsService {
  // inject HttpClient - has http methods and can return an Observable
  constructor(private httpClient: HttpClient) {}

  // http calls
  public addProductHttp(product: Product): Observable<Product> {
    // ========== http headers ===============

    // save token in client side (memory of the browser) - we will get it from server in login method for example
    localStorage.setItem('token', '1212123332');

    // clear the local storage on logout
    // localStorage.removeItem("token");

    // 1. create a HttpHeaders object
    let theHeaders = new HttpHeaders();
    // other ways to  create HttpHeaders object using its CTOR
    let theHeaders2 = new HttpHeaders({
      token: localStorage.getItem('token')!,
      num: '15',
      startDate: '2021-01-01',
    });
    let theHeaders3 = new HttpHeaders('token: 123');

    // 2. get the saved token and put it in the HttpHeaders object
    theHeaders = theHeaders
      .set('token', localStorage.getItem('token')!)
      .set('num', '25')
      .set('startDate', '2021-07-09');

    // 3. create a new object with  a field named 'headers' and the value is the headers object
    let options = { headers: theHeaders2 };
    // =======================================

    // 4. add the options object to the request
    return this.httpClient.post<Product>(
      'http://localhost:8080/product/create',
      product,
      options
    );
  }
  public getProductHttp(id: number): Observable<Product> {
    return this.httpClient.get<Product>(
      'http://localhost:8080/product/read?id=' + id
    );
  }

  public getAllProductsHttp(): Observable<Product[]> {
    return this.httpClient.get<Product[]>(
      'http://localhost:8080/product/read/all'
    );
  }

  // synchrounous
  public getAllProducts(): Product[] {
    let arr: Product[] = [];
    arr.push(new Product(1, 'Apple', 7, 320));
    arr.push(new Product(2, 'Bannana', 4.3, 700));
    arr.push(new Product(3, 'Peach', 12.7, 250));
    arr.push(new Product(4, 'Avocado', 25, 70));
    return arr;
  }

  // asynchrounous
  public getAllProductsAsynch(): Observable<Product[]> {
    return new Observable((subscriber: Subscriber<Product[]>) => {
      setTimeout(() => {
        try {
          if (Math.random() < 0.9) {
            let arr: Product[] = [];
            arr.push(new Product(1, 'Apple', 7, 320));
            arr.push(new Product(2, 'Bannana', 4.3, 700));
            arr.push(new Product(3, 'Peach', 12.7, 250));
            arr.push(new Product(4, 'Avocado', 25, 70));
            subscriber.next(arr); // success
          } else {
            throw new Error('get all products failed');
          }
        } catch (error) {
          subscriber.error(error); // failure
        }
      }, 3000);
    });
  }
}
